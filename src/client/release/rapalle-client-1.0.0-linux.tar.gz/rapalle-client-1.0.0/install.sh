#!/bin/sh
# Installiert den RAPALLE.net RMM Client fuer den aktuellen Benutzer (ohne root):
#   ~/.local/share/rapalle-client, ~/.local/bin/rapalle-client, Startmenue-Eintrag.
# Systemweit (nach /opt):  sudo ./install.sh --system
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ "$1" = "--system" ]; then
  DEST=/opt/rapalle-client; BIN=/usr/local/bin; APPS=/usr/share/applications; ICONS=/usr/share/icons/hicolor/256x256/apps
else
  DEST="$HOME/.local/share/rapalle-client"; BIN="$HOME/.local/bin"; APPS="$HOME/.local/share/applications"
  ICONS="$HOME/.local/share/icons/hicolor/256x256/apps"
fi
command -v python3 >/dev/null || { echo "python3 fehlt (z.B. sudo apt install python3 python3-tk)"; exit 1; }
python3 -c "import tkinter" 2>/dev/null || echo "Hinweis: Tk fehlt - bitte python3-tk (Debian/Ubuntu) bzw. python3-tkinter (Fedora) installieren."
mkdir -p "$DEST" "$BIN" "$APPS" "$ICONS"
cp -r "$HERE/app/." "$DEST/"
printf '#!/bin/sh\nexec python3 "%s/rapalle-client.py" "$@"\n' "$DEST" > "$BIN/rapalle-client"
chmod +x "$BIN/rapalle-client"
cp "$HERE/rapalle-client.png" "$ICONS/rapalle-client.png"
sed "s|^Exec=.*|Exec=$BIN/rapalle-client|" "$HERE/rapalle-client.desktop" > "$APPS/rapalle-client.desktop"
echo "Installiert. Start ueber das Anwendungsmenue oder: $BIN/rapalle-client"
