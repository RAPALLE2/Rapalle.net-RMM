"""RAPALLE.net RMM Client - das Dashboard als eigene App (Windows, Linux, Android)."""
# 1.7.1: MSI-Assistent (mit/ohne Administratorrechte), .exe legt Desktop-Verknuepfung an
# 1.7.0: Adminrechte einmal beim Start (VPN dann ohne Rueckfragen, abgelehnt = VPN aus), „Immer als Administrator starten“
# 1.6.9: alte RMM-Tunnel mit gleicher Adresse werden vor dem Start entfernt (Ursache "Objekt bereits vorhanden")
# 1.6.8: Startpruefung wartet StartPending ab, Rueckfall Klartext-Datei, Admin-Ausgabe/Diagnose ins vpn.log
# 1.6.7: Tunnelstart erst nach dem WireGuard-Manager, kein Parallel-Abgleich manueller Tunnel, Protokoll bei Fehler
# 1.6.6: laufenden Tunnel nie erneut einrichten, verwaiste Adapter entfernen, Doppel-Anforderungen ignorieren
# 1.6.5: Agent + eigener Zugang auf demselben PC erkannt ("über Agent"), Tunnelstart wird geprüft
# 1.6.4: VPN-Bereich im Hauptfenster (Echtzeit), nur EINE Stelle richtet Tunnel ein, Android -> WireGuard-App
# 1.6.3: VPN-Tunnel ohne "existiert bereits"/"Objekt bereits vorhanden" (Sperre, DPAPI, sauberes Neu-Einrichten)
# 1.6.2: keine WireGuard-Fehlerfenster mehr ("kein installierter Dienst"), Tunnel zuverlaessig in der App
# 1.6.1: WireGuard-Tunnel in der WireGuard-App sichtbar, "DLL nicht gefunden" behoben
# 1.6.0: RDP/SSH/VNC + VPN direkt aus dem Dashboard, WireGuard-Datei aktivieren, Netzlaufwerk Windows 11
__version__ = "1.7.1"
